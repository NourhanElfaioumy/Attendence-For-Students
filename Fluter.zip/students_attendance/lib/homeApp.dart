import 'package:students_attendance/homeicon.dart';

import 'cameraicon.dart';
import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';



class HomeApp extends StatefulWidget {
  static const String id = 'HomeApp';
  @override
  _HomeApp  createState() => _HomeApp();

}

class _HomeApp  extends State<HomeApp> {
  int pageIndex = 1;
  final cameraicon _listcameraicon = cameraicon();
  final homeicon _listhomeicon = homeicon() ;
  Widget _showPage = new homeicon();
  Widget _pageChooser(int page){
    switch(page){
      case 0 :
        return _listcameraicon ;
      break ;
      case 1 :
        return _listhomeicon ;
        break ;
      default :
        return new Center(
          child: new Text('No page Found!'),
        );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.1), BlendMode.dstATop),
            image: AssetImage('images/mountains.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child:  _showPage ,
//        new Column(
//          children: <Widget>[
//          ],
//        ),
      ),
      bottomNavigationBar: CurvedNavigationBar(
        index: pageIndex,
        height: 50.0,
        items: <Widget>[
          Icon(Icons.camera, size: 30),
          Icon(Icons.home, size: 30),
        ],
        color: Colors.white,
        buttonBackgroundColor: Colors.green,
        backgroundColor: Color(0xff086788),
        animationCurve: Curves.easeInOut,
        animationDuration: Duration(milliseconds: 200),
        onTap: (int tappedIndex) {
          setState(() {
            _showPage = _pageChooser(tappedIndex);
          });
        },
      ),
    );
  }
}


/*
bottomNavigationBar:BottomNavigationBar(
          items:[
            BottomNavigationBarItem(
              icon:Icon(Icons.home),
            ),
            BottomNavigationBarItem(),
          ]
      ),
 */