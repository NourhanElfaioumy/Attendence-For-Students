import 'package:flutter/material.dart';

const double defaultBorderRadius = 3.0;

enum AppleButtonStyle { white, whiteOutline, black }

class username extends StatefulWidget {
  static const String id = 'UserName';
  @override
  _username  createState() => _username ();

}

class _username   extends State<username>{
  void onPressed(){}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('me',style:TextStyle(fontSize:16.0,color:Colors.white),),
          backgroundColor: Colors.black,
        ),
      body: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.1), BlendMode.dstATop),
            image: AssetImage('images/mountains.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
          child: new Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(left:120.0,right:120.0,top:40.0,bottom:5.0),
                  child: Center(
                    child: Icon(
                      Icons.supervised_user_circle,
                      color: Color(0xff086788),
                      size: 70.0,
                    ),
                  ),
                ),
                new Padding(
                    padding: const EdgeInsets.only(top:0.0,bottom:20.0,right: 20.0,left: 20.0,),
                    child: new Text(
                      "User Name",
                      style: TextStyle(color:Color(0xff086788),fontSize:12.0,fontWeight: FontWeight.bold,
                      ),
                    )
                ),
                //Acount Settings
                new Container(
                  width: MediaQuery.of(context).size.width-20,
                  margin: const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  alignment: Alignment.center,
                  child: new Row(
                    children: <Widget>[
                      new Expanded(
                        child: new RaisedButton(
                            elevation: 0.0,
                            shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(0.0)),
                            padding: EdgeInsets.only(
                                top: 7.0, bottom: 7.0, right: 40.0, left: 0.0),
                            onPressed: () {
//                      Navigator.of(context).pushReplacementNamed(VIDEO_SPALSH);
                            },
                            child: new Row(
                              children: <Widget>[
                                Padding(
                                  padding:EdgeInsets.only(left:10.0),
                                  child: new Image.asset(
                                    'images/setting.png',
                                    height: 40.0,
                                    width: 40.0,
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.only(left: 10.0),
                                    child: new Text(
                                      "Account Settings",
                                      style: TextStyle(
                                          fontSize: 15.0, fontWeight: FontWeight.bold),
                                    ))
                              ],
                            ),
                            textColor: Color(0xFFffffff),
                            color: Color(0xff086788)),
                      ),
                    ],
                  ),
                ),
                //Report Technical Problem
                new Container(
                  width: MediaQuery.of(context).size.width-20,
                  margin: const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  alignment: Alignment.center,
                  child: new Row(
                    children: <Widget>[
                      new Expanded(
                        child: new RaisedButton(
                            elevation: 0.0,
                            shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(0.0)),
                            padding: EdgeInsets.only(
                                top: 7.0, bottom: 7.0, right: 40.0, left: 0.0),
                            onPressed: () {
//                      Navigator.of(context).pushReplacementNamed(VIDEO_SPALSH);
                            },
                            child: new Row(
                              children: <Widget>[
                                Padding(
                                  padding:EdgeInsets.only(left:10.0),
                                  child: new Image.asset(
                                    'images/report.png',
                                    height: 40.0,
                                    width: 40.0,
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.only(left: 10.0),
                                    child: new Text(
                                      "Report Technical Problem",
                                      style: TextStyle(
                                          fontSize: 15.0, fontWeight: FontWeight.bold),
                                    ))
                              ],
                            ),
                            textColor: Color(0xFFffffff),
                            color: Color(0xff086788)),
                      ),
                    ],
                  ),
                ),
                //Help
                new Container(
                  width: MediaQuery.of(context).size.width-20,
                  margin: const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  alignment: Alignment.center,
                  child: new Row(
                    children: <Widget>[
                      new Expanded(
                        child: new RaisedButton(
                            elevation: 0.0,
                            shape: new RoundedRectangleBorder(
                                borderRadius: new BorderRadius.circular(0.0)),
                            padding: EdgeInsets.only(
                                top: 7.0, bottom: 7.0, right: 40.0, left: 0.0),
                            onPressed: () {
//                      Navigator.of(context).pushReplacementNamed(VIDEO_SPALSH);
                            },
                            child: new Row(
                              children: <Widget>[
                                Padding(
                                  padding:EdgeInsets.only(left:10.0),
                                  child: new Image.asset(
                                    'images/help.png',
                                    height: 40.0,
                                    width: 40.0,
                                  ),
                                ),
                                Padding(
                                    padding: EdgeInsets.only(left: 10.0),
                                    child: new Text(
                                      "Help",
                                      style: TextStyle(
                                          fontSize: 15.0, fontWeight: FontWeight.bold),
                                    ))
                              ],
                            ),
                            textColor: Color(0xFFffffff),
                            color: Color(0xff086788)),
                      ),
                    ],
                  ),
                ),
                //Power Button
                new Container(
                  width: MediaQuery.of(context).size.width,
                  margin: const EdgeInsets.only(left: 20.0, right: 20.0, top: 20.0),
                  alignment: Alignment.center,
                  child: new Row(
                    children: <Widget>[
                      new Expanded(
                        child: new FlatButton(
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(30.0),
                          ),
                          color: Colors.green,
                          onPressed: () => {},
                          child: new Container(
                            padding: const EdgeInsets.symmetric(
                              vertical: 10.0,
                              horizontal: 0.0,
                            ),
                            child: new Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                new Expanded(
                                  child: Icon(Icons.power_settings_new,color:Colors.white,size:40,),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ]
          )
      )
    );
  }
}







