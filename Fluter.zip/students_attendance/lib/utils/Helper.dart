class Helper{
  static const String domain = 'http://192.168.43.186:8000/api/';
}