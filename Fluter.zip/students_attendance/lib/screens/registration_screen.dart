import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:students_attendance/api/Register.dart';
import 'package:students_attendance/customized_buttons/customized_textField.dart';
import 'package:students_attendance/customized_buttons/signing_button.dart';
import 'package:students_attendance/homeApp.dart';

class SignUpPage extends StatefulWidget {
  static const String id = 'SignUpPage';
  @override
  _SignUpPage createState() => _SignUpPage();
}

class _SignUpPage extends State<SignUpPage> {
  final _auth = FirebaseAuth.instance;
  void clickMe() async {
    storeUser(userName,email,name,department,level,password).then((user) {
      setState(() async {
        SharedPreferences prefs =  await SharedPreferences.getInstance();
        prefs.setString("token", user.token);
        prefs.setInt("id", user.user.id);
        prefs.setString("department", user.user.department);
        prefs.setString("level", user.user.level);
        Navigator.pushNamed(context, HomeApp.id);
      });
    }, onError: (error)
    {
      setState(() {
        new SnackBar(content: Text("${error.toString()}"));
      });
    });
  }
  String userName;
  String name;
  String phoneNumber;
  String email;
  String displayDep = 'Computer Science';
  String displayLevel = "4";
  String department;
  String level;
  String password;
  var snackBar;
  var changeLevels = ['1', '2', '3', '4'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.1), BlendMode.dstATop),
            image: AssetImage('images/mountains.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: new ListView(
          children: <Widget>[
            Row(
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(left: 60.0),
                  // padding: EdgeInsets.only(left:20.0,right:20.0),
                  // child: Text('SUGNUP PAGE',style: TextStyle(fontSize:20.0,color:Color(0xff086788),fontWeight:FontWeight.bold),),
                ),
                Container(
                  padding: EdgeInsets.only(
                      left: 80.0, right: 80.0, top: 40.0, bottom: 40.0),
                  child: Center(
                    child: Icon(
                      Icons.computer,
                      color: Color(0xff086788),
                      size: 70.0,
                    ),
                  ),
                ),
              ],
            ), //Username
            CustomizedTextField(
              text: 'Save User Name',
              textHint: "Enter Username",
              icon: Icons.supervised_user_circle,
              obSecureText: false,
              onChange: (value) {
                userName = value;
              },
            ),
            CustomizedTextField(
              text: 'Save Name',
              textHint: "Enter Name",
              icon: Icons.supervised_user_circle,
              obSecureText: false,
              onChange: (value) {
                name = value;
              },
            ),//Email
            CustomizedTextField(
              text: 'Save Email',
              textHint: "Enter Email",
              icon: Icons.email,
              obSecureText: false,
              onChange: (value) {
                setState(() {
                  email = value;
                });
              },
            ), //phone
            CustomizedTextField(
              text: 'Save phone',
              textHint: "Phone Number",
              icon: Icons.phone_android,
              obSecureText: false,
              onChange: (value) {
                phoneNumber = value;
              },
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.only(left: 0.0, right: 0.0),
              margin: const EdgeInsets.only(left: 20.0, right: 20.0 ,top: 10.0),
              decoration: BoxDecoration(
                color: Color(0xfff3f3f4),
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                    color:Color(0xff086788), style: BorderStyle.solid, width: 2),
              ),
              child: Center(
                child: Column(
                  children: <Widget>[
                      DropdownButton(
                        underline: SizedBox(),
                        value: displayDep,
                        onChanged : (String newValue) {
                          setState(() {
                            displayDep = newValue;
                            switch(newValue){
                              case 'Computer Science':
                                department = 'cs';
                                changeLevels = ['1', '2', '3', '4'];
                                break;
                              case 'Management Information Systems':
                                department = 'mis';
                                changeLevels = ['1', '2', '3', '4'];
                                break;
                              case 'Accountant':
                                department = 'acc';
                                changeLevels = ['1', '2', '3', '4'];
                                break;
                              case 'Business Administration':
                                department = 'ba';
                                changeLevels = ['4'];
                                displayLevel = "4";
                                break;
                            }
                          });
                        },
                        hint : Text('Select Your Department'),
                        items : <String>['Computer Science','Management Information Systems','Accountant' , 'Business Administration']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        iconSize : 50.0 ,
                      ),
                  ],
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.only(left: 10.0, right: 10.0),
              margin: const EdgeInsets.only(left: 20.0, right: 20.0 ,top: 10.0),
              decoration: BoxDecoration(
                color: Color(0xfff3f3f4),
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                    color:Color(0xff086788), style: BorderStyle.solid, width: 2),
              ),
              child: Center(
                child: Column(
                  children: <Widget>[
                    DropdownButton(
                      isExpanded: true,
                      value: displayLevel,
                      underline: SizedBox(),
                      onChanged :(String newValue) {
                        setState(() {
                          displayLevel = newValue;
                          level = newValue;
                        });
                      },
                      hint : Text('Select Your Academic Level'),
                      items: changeLevels.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      iconSize : 50.0 ,
                    )
                  ],
                ),
              ),
            ),
            //Password
            CustomizedTextField(
              text: 'Save password',
              textHint: "enter password",
              icon: Icons.lock,
              obSecureText: true,
              onChange: (value) {
               setState(() {
                 password = value;
               });
              },
            ),
            //Confirm password
            CustomizedTextField(
              text: 'Save password again',
              textHint: "Confirm password",
              icon: Icons.confirmation_number,
              obSecureText: true,
              onChange: (value) {
                setState(() {
                  if(password == value){
                    snackBar = SnackBar(
                      content: Text('Matching'),
                      backgroundColor: Color(0xff00FF00),
                    );
                  }
                  else{
                    snackBar = SnackBar(
                      content: Text('Not Matching'),
                      backgroundColor: Color(0xffFF0000),
                    );
                  }
                  Scaffold.of(context).showSnackBar(snackBar);
                });
              },
            ),
            //Button SignUp
            SigningButton(
              text: 'SignUp',
              onPressed: clickMe
            ),
          ],
        ),
      ),
    );
  }
}
