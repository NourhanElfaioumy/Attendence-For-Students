import 'package:flutter/material.dart';
import 'package:students_attendance/customized_buttons/welcome_screen_buttons.dart';
import 'package:students_attendance/login.dart';
import 'package:students_attendance/screens/registration_screen.dart';



class LoginSignUp extends StatefulWidget {
  static const String id = 'LoginSignUp';
  @override
  _LoginSignUp  createState() => _LoginSignUp ();

}

class _LoginSignUp  extends State<LoginSignUp > {
  void clickMe(){}
  @override
  Widget build(BuildContext context) {
    return new Container(
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(
        color: Color(0xff086788),
        image: DecorationImage(
          colorFilter: new ColorFilter.mode(
              Colors.black.withOpacity(0.1), BlendMode.dstATop),
          image: AssetImage('images/mountains.jpeg'),
          fit: BoxFit.cover,
        ),
      ),

      child: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[

          // Start SignUp Button
          WelcomeScreenButtons(
            text: 'SignUp',
            onPressed: () => Navigator.pushNamed(context,SignUpPage.id),
          ),

          //START LOGIN BUTTON
          WelcomeScreenButtons(
            text: 'LogIn',
            onPressed: () => Navigator.pushNamed(context,Login.id),
          )
        ],
      ),

    );
  }
}
