import 'package:flutter/material.dart';
import 'welcome_screen.dart';

class Home extends StatelessWidget {
  static const String id = 'home';
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomPadding: false,
        backgroundColor: Colors.white,
        /* appBar: AppBar(
        title: Text(''),
      ),*/
        body:  Stack(
          children: <Widget>[
            LoginSignUp(),
            //successfulRegisterd(),
          ],
        )
    );
  }
}