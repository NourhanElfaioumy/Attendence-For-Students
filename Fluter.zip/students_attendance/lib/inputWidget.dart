import 'package:flutter/material.dart';



class InputWidget extends StatelessWidget {
  final double topRight;
  final double bottomRight;
  InputWidget(this.topRight, this.bottomRight);
  @override
  Widget build(BuildContext context) {
  }
}





