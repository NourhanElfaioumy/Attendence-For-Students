import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:students_attendance/customized_buttons/customized_textField.dart';
import 'package:students_attendance/customized_buttons/signing_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:students_attendance/homeApp.dart';
import 'api/Login.dart';

class Login extends StatefulWidget {
  static const String id = 'LoginScreen';
  @override
  _Login  createState() => _Login();
}

class _Login  extends State<Login> {
  TextEditingController usernameController =TextEditingController();
  TextEditingController passController =TextEditingController();
  final _auth = FirebaseAuth.instance;
  String email;
  String password;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.1), BlendMode.dstATop),
            image: AssetImage('images/mountains.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: new ListView(
            children: <Widget>[
              Container(
                padding: EdgeInsets.only(left:120.0,right:120.0,top:120.0,bottom:70.0),
                child: Center(
                  child: Icon(
                    Icons.computer,
                    color: Color(0xff086788),
                    size: 70.0,
                  ),
                ),
              ),
              //username
              new CustomizedTextField(
                text: 'Save User',
                textHint: "Enter Username",
                icon: Icons.supervised_user_circle,
                obSecureText: false,
                onChange: (value) {
                  email = value;
                },
              ),
              //password
              CustomizedTextField(
                text: 'Save password',
                textHint: "enter password",
                icon: Icons.lock,
                obSecureText: true,
                onChange: (value) {
                  password = value;
                },
              ),
              //Button login
              SigningButton(
                text: 'LogIn',
                onPressed: () {
                  fetchUser(email, password).then((user) {
                    setState(() async{
//                      log('data clicked');
                      SharedPreferences prefs = await SharedPreferences.getInstance();
                      prefs.setString("token", user.token);
                      prefs.setInt("id", user.user_id);
                      prefs.setString("department", user.department);
                      prefs.setString("level", user.level);
                      Navigator.pushNamed(context, HomeApp.id);
                    });
                    }, onError: (error) {
                    setState(() {
                      new SnackBar(content: Text("${error.toString()}"));
                    });
                  });
                },
              ),
            ],
        ),
      ),
    );
  }
}
