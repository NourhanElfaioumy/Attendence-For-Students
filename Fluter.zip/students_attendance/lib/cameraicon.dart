import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:barcode_scan/barcode_scan.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api/Attendance.dart';
import 'api/QRMatch.dart';
import 'homeApp.dart';



class cameraicon extends StatefulWidget {
  @override
  _cameraicon  createState() => _cameraicon();

}

class _cameraicon  extends State<cameraicon> {
  String result = "Hey there !";
  Future _scanQR() async {
    try {
      String qrResult = await BarcodeScanner.scan();
      setState(() {
        result = qrResult;
        log('data $result');
        matchQR(result).then((qr) {
          setState((){
            log('data here');
            if(qr.success == 2){
              new SnackBar(content: Text("${qr.message} : Scanned Successfully"));
              var splitQR = result.split("&");
              storeAttendance(splitQR[2]).then((qr) {
                setState(() {
                  if(qr.success == 3){
                    new SnackBar(content: Text("${qr.message} : Attendance Registered"));
                  }
                });
              }, onError: (error) {
                setState(() {
                  new SnackBar(content: Text("${error.toString()}"));
                });
              });
            }
          });
        }, onError: (error) {
          setState(() {
            new SnackBar(content: Text("${error.toString()}"));
          });
        });
      });
    } on PlatformException catch (ex) {
      if (ex.code == BarcodeScanner.CameraAccessDenied) {
        setState(() {
          result = "Camera permission was denied";
        });
      } else {
        setState(() {
          result = "Unknown Error $ex";
        });
      }
    } on FormatException {
      setState(() {
        result = "You pressed the back button before scanning anything";
      });
    } catch (ex) {
      setState(() {
        result = "Unknown Error $ex";
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          color: Color(0xffffffff),
          image: DecorationImage(
            colorFilter: new ColorFilter.mode(
                Colors.black.withOpacity(0.1), BlendMode.dstATop),
            image: AssetImage('images/mountains.jpeg'),
            fit: BoxFit.cover,
          ),
        ),
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            InkWell(
              child: Image.asset('images/scanme.jpg',),
              onTap: (){
                _scanQR();
              },
            ),
          ],
        ),
      ),
    );
  }
}
