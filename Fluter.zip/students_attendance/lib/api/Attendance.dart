import 'package:shared_preferences/shared_preferences.dart';
import 'package:students_attendance/utils/Helper.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Attendance {
  Attendance(this.success,this.message);
  final int success;
  final String message;
//  Map<String, dynamic>
  factory Attendance.fromJson(json) {
    return Attendance(
      json['success'],
      json['message'],
    );
  }
}
Attendance parseAttendance(String responseBody) {
  return Attendance.fromJson(json.decode(responseBody));
}
Future<Attendance> storeAttendance(lecture_date_id) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  final response = await http.post(
    Helper.domain + 'attendance',
    headers: <String, String>{'Content-Type': 'application/json; charset=UTF-8',},
    body: jsonEncode(<String, String>{
      'id': prefs.getInt("id").toString(),
      'lecture_date_id': lecture_date_id,
      'department': prefs.getString("department"),
      'level': prefs.getString("level"),
    }),
  );
  if (response.statusCode == 200) {
    return parseAttendance(response.body);
  } else {
    throw Exception('Unable to store User Attendance using the REST API');
  }
}