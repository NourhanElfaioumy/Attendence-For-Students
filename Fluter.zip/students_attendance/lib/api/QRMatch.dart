import 'dart:developer';

import 'package:students_attendance/utils/Helper.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class QRMatch {
  QRMatch(this.success,this.message);
  final int success;
  final String message;
//  Map<String, dynamic>
  factory QRMatch.fromJson(json) {
    return QRMatch(
      json['success'],
      json['message'],
    );
  }
}
QRMatch parseMatchQR(String responseBody) {
  return QRMatch.fromJson(json.decode(responseBody));
}
Future<QRMatch> matchQR(qr_code_text) async {
  log('data qr $qr_code_text');
  final response = await http.post(
    Helper.domain + 'qr',
    headers: <String, String>{'Content-Type': 'application/json; charset=UTF-8'},
    body: jsonEncode(<String, String>{
      'qr_code_text': qr_code_text
    }),
  );
  if (response.statusCode == 200) {
    return parseMatchQR(response.body);
  } else {
    throw Exception('Unable to match qr reading using the REST API');
  }
}