import 'package:students_attendance/utils/Helper.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Register{
  Register(this.token,this.user);
  final String token;
  final User user;
  factory Register.fromJson(json) {
    return Register(
      json['token'],
      json['user']
    );
  }
}
class User{
  User(this.id,this.password,this.last_login,this.username,this.email,this.first_name,this.last_name,this.name,this.department,this.level);
  final int id;
  final String password;
  final DateTime last_login;
  final String username;
  final String email;
  final String first_name;
  final String last_name;
  final String name;
  final String department;
  final String level;
  factory User.fromJson(json) {
    return User(
        json['id'],
        json['password'],
        json['last_login'],
        json['username'],
        json['email'],
        json['first_name'],
        json['last_name'],
        json['name'],
        json['department'],
        json['level'],
    );
  }
}
Register parseUser(String responseBody) {
  return Register.fromJson(json.decode(responseBody));
}
Future<Register> storeUser(username,email,name,department,level,password) async {
  final response = await http.post(
    Helper.domain + 'auth/register',
    headers: <String, String>{'Content-Type': 'application/json; charset=UTF-8',},
    body: jsonEncode(<String, String>{
      'username': username,
      'email': email,
      'name': name,
      'department': department,
      'level': level,
      'password': password,
    }),
  );
  if (response.statusCode == 200) {
    return parseUser(response.body);
  } else {
    throw Exception('Unable to register User using the REST API');
  }
}