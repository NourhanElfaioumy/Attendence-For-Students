import 'package:students_attendance/utils/Helper.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Login {
  Login(this.user_id,this.department,this.level,this.token);
  final int user_id;
  final String department;
  final String level;
  final String token;
  factory Login.fromJson(json) {
    return Login(
      json['user_id'],
      json['department'],
      json['level'],
      json['token'],
    );
  }
}
Login parseUser(String responseBody) {
//  log('data parsed');
  return Login.fromJson(json.decode(responseBody));
}
Future<Login> fetchUser(email,password) async {
  final response = await http.post(
    Helper.domain + 'auth/login',
    headers: <String, String>{'Content-Type': 'application/json; charset=UTF-8'},
    body: jsonEncode(<String, String>{
      'username': email,
      'password': password
    }),
  );
  if (response.statusCode == 200) {
//    log('data received');
    return parseUser(response.body);
  } else {
    throw Exception('Unable to fetch User from the REST API');
  }
}