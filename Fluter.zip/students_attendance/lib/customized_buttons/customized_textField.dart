import 'package:flutter/material.dart';

class CustomizedTextField extends StatelessWidget {
  final Function onChange;
  final String text;
  final String textHint;
  final IconData icon;
  final bool obSecureText;
  CustomizedTextField({this.icon , this.textHint , this.text , this.onChange , this.obSecureText});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.only(left: 20.0, right: 20.0, top: 10.0),
      alignment: Alignment.center,
      padding: const EdgeInsets.only(left: 0.0, right: 0.0),
      child: Center(
        child:Column(
          children: <Widget>[
            TextField(
              obscureText: obSecureText,
              onChanged: onChange,
              onEditingComplete: (){print(text);},
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                  filled: true,
                  fillColor: Color(0xfff3f3f4),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xff086788),
                        width: 2,
                        style: BorderStyle.solid),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xff086788),
                        width: 2,
                        style: BorderStyle.solid),
                  ),
                  border: InputBorder.none,
                  hintText: textHint,
                  hintStyle: TextStyle(color: Color(0xFF2D2E2E), fontSize: 14),
                  prefixIcon: Icon(icon,color:Color(0xff086788))
              ),
            ),
          ],
        ),
      ),
    );
  }
}
