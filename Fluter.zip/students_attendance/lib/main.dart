import 'package:flutter/material.dart';
import 'package:students_attendance/screens/welcome_screen.dart';
import 'login.dart';
import 'username.dart';
import 'homeApp.dart';
import 'screens/registration_screen.dart';
import 'package:students_attendance/screens/homeScreen.dart';

void main() => runApp(MyApp());
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowMaterialGrid: false,
      debugShowCheckedModeBanner: false,
      title: 'AFS',
      initialRoute: Home.id,
      routes:{
        Home.id: (context) => Home() ,
        SignUpPage.id: (context) => SignUpPage() ,
        LoginSignUp.id : (context) =>  LoginSignUp(),
        Login.id : (context) => Login(),
        username.id : (context) => username(),
        HomeApp.id : (context) => HomeApp(),
      },
    );
  }
}



